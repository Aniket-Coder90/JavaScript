console.log("This is Third Coding Challenge...")
// *************************************Find Average*********************************************//
// let dolphin_avg = (96+108+89)/3;
// let koalas_avg = (88+91+110)/3;
// console.log(`Average of Team Dolphin : ${dolphin_avg}`);
// console.log(`Average of Team Koalas : ${koalas_avg}`);
// Find Winner
// if(dolphin_avg>koalas_avg){
//     console.log(`Hello, The winner team is Dolphin Trophy`);
// }else if(dolphin_avg == koalas_avg){
//     console.log(`Draw Match, means both team score average are same`)
// }
// else{
//     console.log(`Hello, The Winner team is Koalas Trophy`);
// }
// ******************************************Bonus 1***********************************************//
// let dolphin_avg = (97+112+101)/3;
// let koalas_avg = (109+95+123)/3;
// console.log(`Average of Team Dolphin : ${dolphin_avg}`);
// console.log(`Average of Team Koalas : ${koalas_avg}`);
// Find Winner
// if(dolphin_avg>koalas_avg && dolphin_avg>=100){
//     console.log(`Hello, The winner team is Dolphin Trophy`);
// }else if(dolphin_avg === koalas_avg && koalas_avg>=100){
//     console.log(`Draw Match, means both team score average are same`)
// }else{
//     console.log(`Hello, The Winner team is Koalas Trophy`);
// }
// ********************************************Bonus 2**********************************************//
let dolphin_avg = (97+112+101)/3;
let koalas_avg = (109+95+106)/3;
console.log(`Average of Team Dolphin : ${dolphin_avg}`);
console.log(`Average of Team Koalas : ${koalas_avg}`);
// Find Winner
if(dolphin_avg>koalas_avg && dolphin_avg>=100){
    console.log(`Hello, The winner team is Dolphin Trophy`);
}else if(dolphin_avg === koalas_avg && koalas_avg>=100){
    console.log(`Draw Match, means both team score average are same`)
}else if(dolphin_avg === koalas_avg && dolphin_avg>=100 && koalas_avg>=100){
    console.log(`Hello, The Winner team is Koalas Trophy`);
}else{
    console.log(`Opps!!! Sorry, No one is won this inning.`);
}