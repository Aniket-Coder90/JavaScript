console.log(`This is Coding Challenge 4`);
// const billTip = (275*15)/100;
// console.log(billTip);
// let billTip = 275;
// switch (billTip) {
//     case 275:
//         console.log(`The Bill was ${billTip}, the tip was ${(billTip*15)/100}, and the total value ${((billTip*15)/100) + billTip}`)
//         break;
//     case 
//     default:
//         break;
// }
let bill = 305;
let billTip = 50<=bill<=275 ? (bill*15)/100 : (bill*20)/100;
console.log(billTip);
console.log(`The bill was ${bill}, the tip was ${billTip}, and the Total Value is ${bill + billTip}.`);
// it's not coverd in tutorial
document.write(`The bill was ${bill}, the tip was ${billTip}, and the Total Value is ${bill + billTip}.`);