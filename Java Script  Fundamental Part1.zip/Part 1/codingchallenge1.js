console.log("First Coding Challange");
console.log("Test Data 1 : ")
let markWeight = 78; //weight in KG
let markHeight = 1.69; //height in meter
let johnWeight = 92;
let johnHeight = 1.95;
const markBMI = markWeight / markHeight**2;
const johnBMI = johnWeight / johnHeight**2;
console.log(markBMI,johnBMI);
console.log(markBMI>johnBMI);

console.log("Test Data 2");
markWeight = 95;
markHeight = 1.88;
johnWeight = 85;
johnHeight = 1.76;
console.log(markBMI,johnBMI);
console.log(markBMI>johnBMI);