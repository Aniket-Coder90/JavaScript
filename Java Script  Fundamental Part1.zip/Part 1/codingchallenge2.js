const markHeight = 1.69;
const markWeight = 78;
const johnHeight = 1.95;
const johnWeight = 95;
const markBMI = markWeight / markHeight**2;
const johnBMI = johnWeight / johnHeight**2;
if(markBMI > johnBMI){
    console.log(`Mark BMI ${markBMI} is Higher Then John's ${johnBMI}`);
}else{
    console.log(`John's BMI ${johnBMI} is Higher Than Mark ${markBMI}`);
}