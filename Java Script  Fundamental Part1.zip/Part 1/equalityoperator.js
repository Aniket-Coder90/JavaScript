console.log("Equality Operator");
let age='18';
if(age === 18)console.log(`you became a adult:(strict)`);
if(age == 18)console.log(`You became adult:(loose)`);
if(age != 18)console.log(`He was not 18 Year's old.`);
if(age !== 18)console.log(`He was not in triple equality 18 Year's old.`);

let favoriteNumber = prompt(`What is your favorite number`);
console.log(`That is Your Favorite Number : ${favoriteNumber}`);
console.log(typeof favoriteNumber);
if(favoriteNumber == 18){  //'18' == 18
    console.log(`cool! ${favoriteNumber} year is Good Option For Driving....`);
}
favoriteNumber = Number(prompt(`This is Triple Equality Trial : `));
if(favoriteNumber === 18){  //here 18 === 18
    console.log(`This is Equality operator.`);
} else if(favoriteNumber === 90){
    console.log(`90 is amazing number`);
}
else{
    console.log(`number is not 18 or 90`);
}
if(favoriteNumber !== 90) console.log(`Why Number is Not 90?`);