console.log(`if/else statements`);
const age = 16;
const isOldEnough = age >= 18;
console.log(isOldEnough);
if(isOldEnough){
    console.log("sarah can start driving licence");
}
else{
    const leftAge = 18 - age;
    console.log(`${leftAge} years left`)
}

const birthYear = 1999;
let century; // century is not define here than it will generate error century not defined
if (birthYear<=2000){
    century = 20;  //we can not use defined with let key word
}
else{
    century = 21;
}
console.log(century);

// we can not use this type of using let or undefined variable
/*
const birthYear = 1999;
if(birthYear<=2000){
    let century = 20;
}
else{
    let century = 21;
}
console.log(century);
// Output is century is not defined before that
*/