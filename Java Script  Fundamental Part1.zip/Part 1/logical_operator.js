const hasDriversLicense = true; // A
const haveNotDriversLicense = false;
const hasGoodVision = true;  // B
const hasBadVision = false;
// *****************************Any Of Two are True when AND is True************************************//
console.log(hasDriversLicense && hasGoodVision); //true AND true => true
console.log(hasDriversLicense && hasBadVision); //true AND false => false

// *****************************Any Of One is True When OR is True*************************************//
console.log(hasDriversLicense || hasGoodVision);  //true OR true => true
console.log(hasDriversLicense || hasBadVision);  //true OR false => true
console.log(hasBadVision || hasGoodVision);  //false OR false => true
console.log(haveNotDriversLicense || hasBadVision); //false OR false => false

// **************************** in NOT it's Invert True to False****************************************//
console.log(!hasBadVision); //false to True
console.log(!hasGoodVision); //true to False

const shouldDrive = hasDriversLicense && hasGoodVision;
if(shouldDrive){
    console.log("You Can Drive The Car.");
}else{
    console.log("You Can Not Drive Car.");
}

const isTierd = true;
console.log(hasDriversLicense && hasGoodVision && isTierd);
if(hasDriversLicense && hasGoodVision && !isTierd){
    console.log("You Can Drive The Car.");
}else{
    console.log("You Can Not Drive Car.");
}