// JavaScript Variables
// console.log("Aniket");
// let aniket1 = "Aniket";
// let aniket2 = "Megha";
// var aniket = "aniket";
// console.log(aniket);
// var aniket = "sahil";
// console.log(aniket);
// const a = "aniket";
// console.log(a)
// console.log(a)
// console.log(a)
// // const a = "ajay";
// // let function = "Anijet"
// let $function = "Aniket"
// let number = 90.0012
// console.log(number)
// console.log(typeof(number))
// let children;
// console.log(children);
// let javaScript = false;
// console.log(javaScript);
// javaScript = true;
// console.log(javaScript);
// let ani = '';
// console.log(ani);
// console.log(typeof(ani));

var month = 12;
month = 1;
console.log(month);

let age = 21;
age = '22';
console.log(age)

const birthYear = 1999;
// birthYear = 1998;
console.log(birthYear)

// OPERATOR PRECEDENCE
// MDN(MOZZILLA DEVELOPER NETWORK) IN OPERATOR PRECEDENCE TABLE
// LEFT TO RIGHT AND RIGHT TO LEFT EXECUTION PATH
const now = 2021;
const ageofmegha = now - 1991;
const ageofaniket = now -1999;
console.log(ageofmegha);
console.log(ageofaniket);
console.log('diffrence between age of megha and aniket : ' + (ageofmegha - ageofaniket))
console.log(25+35-105);
console.log("Aniket Is Small? True/False : "+(ageofmegha>ageofaniket))
console.log("Who is Big ? Aniket / Megha ")
let x,y;
x = y = 25-15+10;
console.log(x, y);
let ageavg = (ageofmegha + ageofaniket)/1;
console.log(ageavg);