let firstname = "Aniket";
let position = "Web Developer";
let age = 21
console.log("i'm " + firstname + " and i'm " + position + " and i'm " + age + "years old.")
console.log(`I'm ${firstname}, i'm ${position}, i'm ${age} years old.` + `this is ES6 Feature`); //ES6 Feature
console.log(`just a regular string...`)
// multiple lines in JS
console.log('this is \n\
multiple \n\
line string.');
console.log('this is \n\ also \n\ multiple lines...')
console.log(`this is feature
of multile in
ES6 to write code...`);