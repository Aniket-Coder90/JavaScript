console.log(`This is Switch Statement`);
const day = 'Tuesday';
// switch (day) {
//     case 'monday':  // day === 'monday'
//         console.log(`Plan Course Structure`);
//         console.log('Go to coding meet up');
//         break;
//     case 'Tuesday':
//         console.log(`Prepare Theory Videos`);
//         break;
//     case 'Wednesday':
//     case 'Thursday':
//         console.log("Prepare for Practical Guides");
//         break;
//     case 'Friday':
//         console.log("use the internate and rich goal");
//         break;
//     case 'saturday':
//     case 'sunday':
//         console.log(`The Saturday and sunday both are Holidays`);
//         break;
//     default:
//         console.log(`This is Week Time Table`);
// }

if (day === 'monday'){
    console.log(`Plan Course Structure`);
    console.log('Go to coding meet up');
}else if(day === 'Tuesday'){
    console.log(`Prepare Theory Videos`);
}else if(day === 'Wednesday' || day === 'Thursday'){
    console.log("Prepare for Practical Guides");
}else if(day === 'Friday'){
    console.log("use the internate and rich goal");
}else if(day === 'saturday' || day === 'sunday'){
    console.log(`The Saturday and sunday both are Holidays`);
}else{
    console.log(`This is Week Time Table`);
}