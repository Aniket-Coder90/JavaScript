console.log(`conditional operator`);
const age = 26;
// age >= 18 ? console.log('I Want To Drive Car.') : console.log(`I dont't want to drive the car.`);

const drive = age >= 18 ? `drive` : `can't drive`;
console.log(drive);