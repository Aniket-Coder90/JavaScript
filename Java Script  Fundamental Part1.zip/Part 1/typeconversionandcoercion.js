// Type Conversion
const birthYear = `1991`;
console.log(birthYear);
console.log(typeof(birthYear));
console.log(Number(birthYear));
console.log(Number('Aniket'));
console.log(typeof NaN);
console.log(String(23), 23);
console.log(typeof String(23));

// Type Coercion
console.log('I am ' + 23 + 'years Old.');
console.log('23' - '10' - 3);  //string to number convert autoatically
console.log('23' * '2');  // string to number convert automatically
console.log('23' + '10' + 3);  //if can be string concatinations
console.log('22' / '2');
console.log('22' > '18');

let n = '1' + 1;
n = n - 1;
console.log(n);


// Truthy And Falsy Values in JavaScript
// 5 falsy values in JavaScript : 0, ' ', undefined, null, NaN
console.log(Boolean(0));
console.log(Boolean(undefined));
console.log(Boolean('aniket'));
console.log(Boolean({}));   //{} is empty Object

const money = 0;
if (money){
    console.log("You Can't spend it all ;)");
}else{
    console.log("You should Get a job!!!");
}

let height;
if(height){
    console.log(`YAY! Height is Defined.`);
}
else{
    console.log(`Height is UNDEFINED`);
}