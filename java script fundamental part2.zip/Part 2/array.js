console.log("THIS IS DATA STUCTURE IN JAVA SCRIPT");
const friend1 = `Sanket`;
const friend2 = `Piyush`;
const friend3 = `Hiren`;
// Create Array
const friends = ['Sanket','Hiren','Piyush'];
console.log(friends);
// other method to create array
const year = new Array(2020,2021,2022,2023);
console.log(year);

console.log(year.length);
console.log(friends.length);
console.log(friends[friends.length - 1]);   //friends.length = 3
console.log(friends[friends.length]);
// We can add value in array
friends[3] = 'Yash';
console.log(friends);
// we can change value in array
friends[2] = 'YP';
console.log(friends);
// we can not add two value as like this method
friends[4,5] = 'Piyush','Chakli';
console.log(friends);
// we can add array in array as like this method
friends[6] = ['Piyush','Chakli'];
console.log(friends);

// other method for array
const firstname = "Aniket";
const aniket = [firstname, "Prajapati ", 2021 - 1999, " years old", friends];
console.log(aniket);

// Exersice of Array
const calcAge = function(birthyear){
    return 2021 - birthyear;
}
const years = [1990, 1999, 1967, 1960, 2020];
const age1 = calcAge(years[0]);
const age2 = calcAge(years[1])
const age3 = calcAge(years[3])
const age4 = calcAge(years[years.length - 1])
console.log(age1, age2, age3, age4);
const age = [calcAge(years[0]), calcAge(years[1]), calcAge(years[3]), calcAge(years[years.length - 1])];
console.log(age);

// ************************************* Array Basics Operations Methods *********************************
// ######################################## Add Elements ##########################################
console.log(friends);
friends.push('Megha') // For Add Value in  array
console.log(friends)
// ************************************************************************************************
friends.unshift('Dev');  //using unshift method we can add value at the begining of array or first or at 0th index
console.log(friends);
// ***********************************************************************************************

// ###################################### Remove Elements ##########################################
// *** Use pop Method ***//
friends.pop(1);   //pop use to delete/remove last element in array  Last in first Out
console.log(friends);
const popup = friends.pop();
console.log(popup);
console.log(friends);

// *************************************************************************************************
// *** Use Shift Method *** //
friends.shift();    // it can be use for delete first element in array at the index no of 0.
console.log(friends);


// ########################################## find index ##############################################
// *** indexOf *** //
friends.push(23);   // we can add 23 for check string equality
console.log(friends);
const stringequality = friends.includes('23');  // here it will be check 23 === '23'
console.log(stringequality);

const indexNo2 = friends.includes('Aniket');    // ig return true or false, it was a ES Feature
console.log(indexNo2);

const indexNo = friends.indexOf('Piyush');
const indexNo1 = friends.indexOf('ANIKET');  // THIS ELEMENT IS NOT PRESENT IN ARRAY
console.log(indexNo);
console.log(indexNo1);

if (friends.includes('Piyush')){
    console.log("Find Out");
}
// friends.reverse();  //for reverce to the array
// console.log(friends);
// console.log(friends[1]);