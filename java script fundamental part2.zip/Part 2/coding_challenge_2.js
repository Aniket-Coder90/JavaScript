console.log(`This is Second Coding Challenge...`);
// function calcTip(bill){
//     if (50 < bill < 300) {
//         const tip = (bill * 15) / 100;
//         return console.log(`Tip is 15% from bill than tip is ${tip}`);
//     }
//     else if (bill >= 300) {
//         const tipIs = (bill * 20) / 100;
//         return console.log(`Tip is 20% from bill then tip is ${tipIs}`);
//     }
//     else {
//         return console.log(`Tip is Not Valid for ${bill}`);
//     }
// }
// calcTip(1000);

// const calcTip = function(bill) {
//     return bill >= 50 && bill <= 300 ? bill * 0.15 : bill * 0.20;
// }
// console.log(calcTip(20));

const calcTip = (bill) => {
    return bill >= 50 && bill <= 300 ? bill * 0.15 : bill * 0.20;
}
console.log(calcTip(250));

const bills = [125, 555, 44];
const tips = [calcTip(bills[0]), calcTip(bills[1]), calcTip(bills[2])];
console.log(bills, tips);
const totals = [(bills[0] + tips[0]), (bills[1] + tips[1]), (bills[2] + tips[2])];
console.log(totals);