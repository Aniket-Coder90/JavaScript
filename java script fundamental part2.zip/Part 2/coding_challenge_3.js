console.log("Hiii This is Third coding challenge...");
const mark = {
    fullname : 'Mark Miller',
    mass : 78,
    height : 1.69,
    calcBMI : function(){
        return this.mass / this.height**2;
    }
}
console.log(mark.calcBMI());
const john = {
    fullname : 'John Smith',
    mass : 92,
    height : 1.95,
    calcBMI : function(){
        return this.mass / this.height**2;
    }
}
const higherBMI = () => {
if(mark.calcBMI()>john.calcBMI()){
    return `${mark.fullname}'s BMI (${mark.calcBMI()}) is Higher than ${john.fullname}'s BMI (${john.calcBMI()})`;
}
else{
    return `${john.fullname}'s BMI (${john.calcBMI()}) is Higher than ${mark.fullname}'s BMI (${mark.calcBMI()})`;
}
}
console.log(john.calcBMI());
console.log(higherBMI())