console.log(`Coding challenge 4`);
const bills = [22, 295, 176, 440, 37, 105, 10, 1100, 86, 52];
console.log(bills);

const tips = [];
const totals = [];

const calcTip = function(bill) {
    return bill >= 50 && bill <= 300 ? bill * 0.15 : bill * 0.2;
}
for(let i = 0; i < bills.length; i++){
    const tip = calcTip(bills[i]);
    tips.push(tip);
    totals.push(tip + bills[i])
}
console.log(tips);
console.log(totals);

// BONUS CHALLENGE

const calcAverage = function(arr){
    let sum = 0;
    for (let i = 0; i < arr.length; i++){
        // sum = sum + arr[i];
        sum += arr[i];
    }
    // console.log(sum);
    return sum / arr.length;
}
// calcAverage([2,3,6]);
console.log(calcAverage([2,3,6]));
console.log(calcAverage(totals));
console.log(calcAverage(tips));