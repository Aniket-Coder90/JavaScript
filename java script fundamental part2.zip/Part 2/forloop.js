console.log(`This is For Loop`);
console.log(`Lifting Weights repetation 1 🏋️‍♂️`);

// FOR LOOP RUNNING WHILE CONDITION IS TRUE
for(let rep = 1; rep <= 10; rep++){
    console.log(`Lifting Weights repetation ${rep} 🏋️‍♀️`);
}

const aniketArray = [
    'aniket',
    'prajapati',
    2037 - 1999,
    'Founder Of Digital Dave',
    ['Sanket','Yash Yp😏','Piyush','Hiren'],
    true
];

// for(let i = 0; i <= aniketArray.length - 1 ; i++){
//     console.log(aniketArray[i]);
// }
// OR
const types = [];
for(let i = 0; i < aniketArray.length ; i++){
    // Reading from aniketArray
    console.log(aniketArray[i]);
    // This is Way for Filling Array
    // types[i] = typeof aniketArray[i];
    types.push(typeof aniketArray[i]);
}
console.log(types);

// Filling Array
const years = [1968, 1989, 1991, 1999, 2020];
const ages = [];
for (let i = 0; i < years.length; i++) {
    ages.push(2037-years[i]);
}
console.log(ages);

// continue and break
console.log('--- ONLY STRING CONTINUE STATEMENT ---');
for(let i = 0; i < aniketArray.length; i++){
    if(typeof aniketArray[i] !== 'string') continue;

    console.log(aniketArray[i], typeof aniketArray[i])
}

console.log('--- BREACK STATEMENT ---');
for(let i = 0; i < aniketArray.length; i++){
    if(typeof aniketArray[i] === 'number') break;

    console.log(aniketArray[i], typeof aniketArray[i])
}



// Loop Backward and loop in loop
const aniket = [
    'aniket',
    'prajapati',
    2037 - 1999,
    'Founder Of Digital Dave',
    ['Sanket','Yash Yp😏','Piyush','Hiren']
];
console.log('LOOPING BACKWORD AND LOOP IN LOOP');
for (let i = aniket.length - 1; i >= 0; i--){
    console.log(aniket[i]);
}

// loop in loop
for (let exersise = 1; exersise < 4; exersise++){
    console.log(`----------EXERCIESE ${exersise}`);
    for (let rep = 1; rep < 6; rep++){
        console.log(`Exerciese ${exersise} Lifting waiting repetation ${rep}`);
    }
}