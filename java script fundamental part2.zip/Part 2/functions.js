function logger() {
    console.log(`This is First Java Script Function`);
}
// calling / running / invoking function
logger(); // function use many time in code
logger();
logger();
logger();
logger();

function fruitProcessor(oranges,mangoes){
    console.log(oranges,mangoes);
    const juice = `Juice with ${oranges} oranges, and ${mangoes} mangoes.`;
    return juice;
}
// console.log(fruitProcessor(3,5));
const fruitsJuice = fruitProcessor(3,5);
console.log(fruitsJuice);

// ***************************************Function Declaration vs. Expressions******************************//
/* *******************************************Function Declaration */
function calcAge1(birthYear){
    return 2037 - birthYear;
}
const age1 = calcAge1(1999);
console.log(age1);

/* before declare function */

const age12 = calcAge12(1999);
console.log(age12);
function calcAge12(birthYear2){
    return 2020 - birthYear2
}
console.log(age12);
/* ******************************************Function Expression*/
// anonymouse function
const calcAge2 = function (birthYear1){
    return 2050 - birthYear1;
}
const age2 = calcAge2(1999);
console.log(age2);
/* before function expression is not use to this it generat error */
/* 
const age22 = calcAge22(1999);
console.log(age22);
const age22 = function (birthYear3){
    return 2020 - birthYear3;
}
*/
/* *****************************************ARROW FUNCTION**************************************** */
//Function Expression
const agecalc = function(yearofbirth){
    return 2070 - yearofbirth;
}
console.log(agecalc(1999));
// Arrow Function
const agecalc1 = yearofbirth1 => 2070 - yearofbirth1;
const calcAgeofaniket = agecalc1(1999);
console.log(calcAgeofaniket)
// 
const yearsUntillRetirement = (birthYeah, firstname) => {
    const age = 2020 - birthYeah;
    const retirement = 45 - age;
    // return retirement;
    return `I am ${firstname}, and my retirement has only ${retirement} years left.`
}
console.log(yearsUntillRetirement(1999, 'Aniket'));
console.log(yearsUntillRetirement(1979, 'Jay'));

/* **********************************Function Calling Other Functions********************************* */
function cutFruitPieces(fruit){
    return fruit * 4;
}
function fruitProcessor(apples,oranges){
    const applePieces = cutFruitPieces(apples);
    const orangePieces = cutFruitPieces(oranges);

    const juice = `Juice With ${applePieces} pieces of apple and ${orangePieces} pieces of orange.`;
    return juice;
}
const fruitpieces = fruitProcessor(2,3);
console.log(fruitpieces);

// ################################## Review The Function ##############################################
const calcAge = function (birthYeah){
    return 2037 - birthYeah;
}
const yearsUntillRetirements = function(birthYeah, firstname){
    const age = calcAge(birthYeah);
    const retirement = 65 - age;

    if (retirement > 0){
        return retirement;
    }else{
        console.log(`${firstname} has Already Retierd.`);
    }
    // return `${firstname} reties in ${retirement} years`;
}
console.log(yearsUntillRetirements(1992, 'Aniket'));
yearsUntillRetirements(1969, 'John');