/*const aniketArray = [
    'Aniket',
    'Prajapati',
    2021 - 1999,
    'Founder of Digital Dave',
    ['Ssanket','Yash Soni','Yash Yp😏','Piyush','Hiren']
];*/
// CREATING OBJECTS IN JAVASCRIPT WITH USING {KEY:VALUE}
/*const aniket = {
    firstName : 'Aniket',
    lastName : 'Prajapati',
    age : 2021 - 1999,
    job :'Founder Of Digital Dave',
    friends : ['Ssanket','Yash Soni','Yash Yp😏','Piyush','Hiren']
};
*/


// DOTS. VS BRACKETS NOTATIONS
/*
const aniket = {
    firstName : 'Aniket',
    lastName : 'Prajapati',
    age : 2021 - 1999,
    job :'Founder Of Digital Dave',
    friends : ['Ssanket','Yash Soni','Yash Yp😏','Piyush','Hiren']
};
console.log(aniket);
console.log(aniket.lastName);
console.log(aniket['friends']);

const nameKey = 'Name';
console.log(aniket['first' + nameKey]);
console.log(aniket['last' + nameKey]);
*/
// console.log(aniket.'last' + nameKey);      // THIS DOT STRING METHOD IS NOT USING

// const intrestedIn = prompt('What do you want to know about Aniket? Choose between firstName, lastName, age, job and friends.');
// console.log(intrestedIn);
// console.log(aniket.intrestedIn);    //aniket HAVE NOT PROPERTY OF THE intrestedIn
// console.log(aniket[intrestedIn]);   // we can use BRACKET NOTATION HERE WE CAN NOT USE DOT NOTATIONS
/*
if (aniket[intrestedIn]) {
    console.log(aniket[intrestedIn]);
}else{
    console.log(`Wrong Input! Choose between firstName, lastName, age, job and friends.`);
};
*/

// WE CAN ADD IN OBJECT WITH THIS TYPE OF METHOD
/*
aniket.location = 'india';
aniket['instagram'] = 'anigha13187';
console.log(aniket);

console.log(`${aniket.firstName} has ${aniket.friends.length} friends and his best friend is ${aniket.friends[0]}`);
*/


// OBJECTS METHODS
/*
const aniket = {
    firstName : 'Aniket',
    lastName : 'Prajapati',
    birthYear : 1999,
    job :'Founder Of Digital Dave',
    drivingLicence : false,
    friends : ['Sanket','Yash Soni','Yash Yp😏','Piyush','Hiren'],
    // calcAge : function(birthYear){
    //     return 2037 - birthYear;
    // },

    // calcAge : function(){
    //     console.log(this);      // this key word no use j object ma hoy function aeni j property access karva mate thay
    //     return 2037 - this.birthYear;       // this keyword only use karvathi aakho object get thay but property like this.birthyear thi a j object ni property ni value get kare
    // } 

    calcAge : function(){
        this.age = 2037 - this.birthYear;       // we can add age property using this keyword
        console.log(this);
        return this.age;
    }

};
*/
// console.log(aniket.calcAge())

// console.log(aniket.calcAge(1999));
// console.log(aniket.calcAge(aniket.birthYear));
// console.log(aniket.calcAge(aniket['birthYear']));

// CHALLENGE
// first method

const aniket = {
    firstName : 'Aniket',
    lastName : 'Prajapati',
    birthYear : 1999,
    job :'Founder Of Digital Dave',
    drivingLicence : false,
    friends : ['Sanket','Yash Soni','Yash Yp😏','Piyush','Hiren'],
    // calcAge : function(birthYear){
    //     return 2037 - birthYear;
    // },

    // calcAge : function(){
    //     console.log(this);      // this key word no use j object ma hoy function aeni j property access karva mate thay
    //     return 2037 - this.birthYear;       // this keyword only use karvathi aakho object get thay but property like this.birthyear thi a j object ni property ni value get kare
    // } 

    calcAge : function(){
        this.age = 2037 - this.birthYear;       // we can add age property using this keyword
        console.log(this);
        return this.age;
    },
    getSummary : function(){
        return `${this.firstName} is a ${this.calcAge()} years old ${this.job}, and he has ${this.drivingLicence ? 'a' : 'no'} driver's liecence.`
    }
};
console.log(aniket.getSummary());
// second method
console.log(`${aniket.firstName} is a ${aniket.calcAge()} years old ${aniket.job}, and he has ${aniket.drivingLicence ? 'a' : 'no'} driver's liences.`);