'use strict';   //here if comment this than not showing error

let hasDriversLicense = false;
const passTest = true;
if(passTest) hasDriverLicense = true;     // error here
if(hasDriversLicense) console.log("You Can Drive The Vehical");

const interface = "Audio";      // error here