console.log(`While Loop`);
let i = 1;
while(i < 11){
    console.log(`10 Out of ${i}`);
    i++;
}

let dice = Math.trunc((Math.random() * 8) + 1);
console.log(dice);

while(dice !== 8){
    console.log(`You Rolled ${dice}`);
    dice = Math.trunc((Math.random() * 8) + 1);
    if(dice === 8) console.log(`Loop Abort....`);
}